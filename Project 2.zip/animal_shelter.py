from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://localhost:42659')
        #self.client = MongoClient('mongodb://%s:%s@localhost:42659/authMechanism=DEFAULT&authSource=AAC' % ('aacuser', 'password'))
        # where xxxx is your unique port number
        self.database = self.client['AAC']

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be dictionary 
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False
    
    # read functions
    def read_all(self, data):
        cursor = self.database.animals.find(data, {'_id':False} ) ## return a cursor which a pointer to a list of results ( documnets )
        return cursor
    
    def read(self, data):
        if data is not None:
             return self.database.animals.find(data, {"_id":False}) ## returns one document
        else:
            return "Nothing to search, because data parameter is empty"
        
        #Update function
    def update(self, data,new_data):
        if data is not None:           #return if 1 item or more is updated
            result = self.database.animals.update_one(data,new_data)
            return result.matched_count>0
        else:
            updateException = "No results found"
            raise Exception(updateException)
            
            
        #Delete function
    def delete(self,data):
        if data is not None:     #return if atleast 1 or more items are deleted
            result = self.database.animals.delete_one(data)
            return result.deleted_count>0
        else:
            deleteException = "Nothing to delete."
            raise Exception("deleteException")
